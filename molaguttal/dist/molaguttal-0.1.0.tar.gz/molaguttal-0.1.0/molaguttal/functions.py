def sum(x,y):
    return x + y;

def avg(x,y):
    return (x + y)/2;

def subtract(x,y):
    return (x - y);