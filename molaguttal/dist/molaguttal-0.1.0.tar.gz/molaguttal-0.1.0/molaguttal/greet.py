def hey(name):
    print("hello ", name)